#ifndef PILE_H
#define PILE_H

#include <stdbool.h>
#include "listes.h"
typedef sequence_t pile_t;

void initialiser(pile_t *pile);
void empiler(pile_t *pile, int x,cellule_t *groupe);
int depiler(pile_t *pile,cellule_t **groupe);
void soustraction(pile_t *pile);
void addition(pile_t *pile);
void multiplication(pile_t *pile);
void afficher_pile(pile_t *pile);
void afficher_groupe_pile(cellule_t *groupe);
cellule_t *obtenir_bvf(pile_t *pile);
#endif
