#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <assert.h>
#ifdef NCURSES
#include <ncurses.h>
#endif
#include "listes.h"


/*
 *  Auteur(s) : Anais Belal / Feth-Ellah Boudellal
 *  Date : 01/11/2023
 *  Suivi des Modifications :
 *
 */

bool silent_mode = false;


cellule_t* nouvelleCellule (void)
{
    cellule_t *cel=malloc(sizeof(cellule_t));
    if (cel == NULL) {
        printf("Erreur");
    }
    return cel;
}


void detruireCellule (cellule_t* cel)
{
    free(cel);
}
/*
// char *texte ---- TAB[0] "\0"
void conversion (char *texte, sequence_t *seq)
{
    cellule_t *cel = nouvelleCellule();
    cellule_t *tmpcel;
    cellule_t *tmpgroup;
    int depth = 0;
    seq->tete = NULL;
    if(seq->tete == NULL){
        cel->command = *texte;
        cel->suivant = NULL;
        cel->groupe = NULL;
        tmpcel = cel;
        seq->tete = cel;
    }
    while (*texte != '\0') {
        cellule_t *cel = nouvelleCellule();
        texte = texte + 1;
            if(*texte == '{'){
                cel->command = GroupeDeCmd;
                tmpcel->suivant = cel;
                tmpcel = cel;
                texte = texte + 1;
                depth++;
                if(*texte != '}'){
                    cellule_t *groupe = nouvelleCellule();
                    groupe->command = *texte;
                    groupe->suivant = NULL; // FUNCTION APRES
                    groupe->groupe = NULL;
                    tmpcel->groupe = groupe;
                    texte = texte + 1;
                    tmpgroup = groupe;
                    if(*texte != '}') {
                        while (depth != 0){
                            if(*texte == '{'){
                                depth++;
                            } else if(*texte == '}'){ // change + 1
                                depth--;
                            }
                            cellule_t *groupe = nouvelleCellule();
                            groupe->command = *texte;
                            groupe->suivant = NULL; // FUNCTION APRES
                            groupe->groupe = NULL;
                            tmpgroup->suivant = groupe;
                            tmpgroup = groupe;
                            texte = texte + 1;
                        }
                    }
                }else{
                    depth--;
                    cellule_t *groupe = nouvelleCellule();
                    groupe->command = Vide;
                    groupe->suivant = NULL; // FUNCTION APRES
                    groupe->groupe = NULL;
                    tmpcel->groupe = groupe;
                    tmpgroup = groupe;
                    texte = texte + 1;
                }
            }
            else {
                    cel->command = *texte;
                    cel->suivant = NULL;
                    cel->groupe = NULL;
                    tmpcel->suivant = cel;
                    tmpcel = cel;
            }
        }

        // LIS// CREE CELLULE// INSERTION F LA FIN// ++

} */
void conversion(char *texte, sequence_t *seq) {
    int i;
    for (i = strlen(texte) - 1; i >= 0; i--) { // On lit de dernier caracter au premier
        ajoute_tete(seq, texte[i]);
    }
}


void afficher (sequence_t* seq)
{
    assert (seq); /* Le pointeur doit être valide */
    cellule_t *c,*tmp;
    c = seq->tete;
    /*while(c->suivant != NULL ){
            c = c->suivant;
            if(c->command != GroupeDeCmd){
                printf("%c", c->command);
        } else{
                tmp = c->groupe;
                afficher_groupe(tmp);
            }
    }*/
    while(c->suivant != NULL){
        if(c->command != GroupeDeCmd){
            printf("%c", c->command);
        } else{
            tmp = c->groupe;
            afficher_groupe(tmp);

        }
        c = c->suivant;
    }
}
void command(sequence_t* seq,char *cmd,cellule_t **groupe){
    cellule_t *tmp; // temporary
    tmp = seq->tete; // VERS PREMIERE CELLULE
        seq->tete = tmp->suivant;// JE CHANGE L'@ DE TETE VERS LA DEUXIEME CELLULE = TMP-SUIVANT----DEUXIEME
        *cmd = tmp->command;
        *groupe = tmp->groupe;
    detruireCellule(tmp);
}

void afficher_groupe(cellule_t *groupe){
    printf("{");
    while (groupe->suivant != NULL){
        printf("%c", groupe->command);
        groupe = groupe->suivant;
    }
    if(groupe->command != Vide){
        printf("%c", groupe->command);
    }
    printf("}");
}

void obtenir_groupe(sequence_t *seq,cellule_t **groupe){
    *groupe = seq->tete;
    cellule_t *tmp = *groupe;
    while(tmp->suivant == NULL){
        tmp = tmp->groupe;
    }
    seq->tete = tmp->suivant;
    tmp->suivant = NULL;
}

cellule_t *concatener(cellule_t *g1,cellule_t *g2){
    if(g1 == NULL) return g2;
    else{
        queue(g1)->suivant = g2;
        return g1;
    }
}
cellule_t *queue(cellule_t *g1){
    while(g1->suivant != NULL) {
        g1= g1->suivant;
    }
    return g1;
}

cellule_t *validation(cellule_t *g) {
    char *texte = NULL;
    int i = 0;

    // Calculate the length of the text first to allocate memory.
    int text_length = 0;
    cellule_t *current = g;
    while (current != NULL) {
        text_length++;
        current = current->suivant;
    }

    texte = (char *)malloc(text_length + 1); // +1 for the null terminator

    if (texte == NULL) {
        // Handle memory allocation failure
        return NULL;
    }

    i = 0;
    current = g;
    while (current != NULL) {
        texte[i] = current->command;
        current = current->suivant;
        i++;
    }

    // Null-terminate the string
    texte[i] = '\0';

    sequence_t nouvelle_seq;
    conversion(texte, &nouvelle_seq);

    // Don't forget to free the allocated memory when done with 'texte'
    free(texte);

    return nouvelle_seq.tete;
}

void validate_texte(char *texte) {
    int length = strlen(texte);
    char *temp = malloc(length * 2 + 1); // Allocate a temporary buffer

    if (temp == NULL) {
        printf("Memory allocation failed.");
        return;
    }

    int i, j = 0;
    int insideString = 0; // Flag to keep track if inside a string
    int braceDepth = 0; // Keep track of brace nesting level

    for (i = 0; i < length; i++) {
        if (texte[i] == '\"') {
            insideString = !insideString; // Toggle the insideString flag when a double quote is encountered
        }

        if (insideString) {
            temp[j++] = texte[i];
        } else if (texte[i] == '{') {
            braceDepth++;
            temp[j++] = texte[i];
        } else if (texte[i] == '}') {
            braceDepth--;
            temp[j++] = texte[i];
            if (i < length - 1 && texte[i + 1] != ' ' && braceDepth == 0) {
                temp[j++] = ' ';
            }
        } else {
            temp[j++] = texte[i];
        }
    }

    temp[j] = '\0';

    strcpy(texte, temp); // Copy the modified string back to the original variable

    free(temp); // Free the temporary buffer
}
/*
void ajouter_seq(char command, sequence_t *seq,cellule_t *derniere_cell){
    cellule_t *nvccellule = nouvelleCellule();
    nvccellule->command = command;
    nvccellule->suivant = derniere_cell;
    derniere_cell = nvccellule;
    seq->tete = nvccellule;
}*/
void ajoute_tete(sequence_t *seq, char command) {
    cellule_t *nvcell = nouvelleCellule();
    nvcell->command = command;
    nvcell->suivant = seq->tete;
    seq->tete = nvcell;
}

