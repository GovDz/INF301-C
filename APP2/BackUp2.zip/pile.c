#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#ifdef NCURSES
#include <ncurses.h>
#endif
#include "pile.h"
// PILE = LIFO = LAST IN FIRST OUT
void initialiser(pile_t *pile){
    pile->tete = NULL;
}
void empiler(pile_t *pile, int x,cellule_t *groupe){
    if(x != GroupeDeCmd && groupe == NULL){
        cellule_t *nouvelle_case = malloc(sizeof(cellule_t));
        nouvelle_case->valeur=x;
        nouvelle_case->suivant = pile->tete;
        pile->tete = nouvelle_case;
    } else {
        cellule_t *nouvelle_case = malloc(sizeof(cellule_t));
        nouvelle_case->valeur=x;
        nouvelle_case->suivant = pile->tete;
        nouvelle_case->groupe = groupe;
        pile->tete = nouvelle_case;
    }

}
int depiler(pile_t *pile,cellule_t **groupe){
    int valeur;
    if (pile->tete == NULL){
        printf("ERROR , PILE EST VIDE");
    }
    cellule_t *tmp = pile->tete;
    valeur = tmp->valeur;
    pile->tete = tmp->suivant;
    if (valeur == GroupeDeCmd){
        *groupe = tmp->groupe;
    }
    return valeur;
    detruireCellule(tmp);
}
void soustraction(pile_t *pile){
    int a,b;
    a = depiler(pile,NULL);
    b = depiler(pile,NULL);
    empiler(pile,a-b,NULL);
}
void addition(pile_t *pile){
    int a,b;
    a = depiler(pile,NULL);
    b = depiler(pile,NULL);
    empiler(pile,a+b,NULL);
}
void multiplication(pile_t *pile){
    int a,b;
    a = depiler(pile,NULL);
    b = depiler(pile,NULL);
    empiler(pile,a*b,NULL);
}

void afficher_pile(pile_t *pile){
    cellule_t *tmp = pile->tete;
    cellule_t *groupe;
    while (tmp != NULL){
        if(tmp->valeur == GroupeDeCmd){
            groupe = tmp->groupe;
            afficher_groupe_pile(groupe);
            printf("--");
        } else{
            printf("%d--",tmp->valeur);
        }
        tmp = tmp->suivant;
    }
    printf("E");

}


void afficher_groupe_pile(cellule_t *groupe){
    printf("{");
    while (groupe->suivant != NULL){
        printf("%c", groupe->command);
        groupe = groupe->suivant;
    }
    printf("%c", groupe->command);
    printf("}");
}
cellule_t *obtenir_bvf(pile_t *pile){
    int checker;
    cellule_t *final1 = NULL;
    cellule_t *final2 = NULL;
    depiler(pile,&final1);
    depiler(pile,&final2);
    checker = depiler(pile,NULL);
    if (checker){
        // free groupe
        return final2;
    } else return final1;
}
void group_detecte(sequence_t *seq,pile_t *pile){
    cellule_t *x = nouvelleCellule();
    cellule_t *y = nouvelleCellule();
    *x = *seq->tete;
    y = x;
    int n = 1;
    while (n != 0) {
        if (y->command == '{')
            n++;
        if (y->command == '}')
            n--;
        if (n == 0) {
            *seq->tete = *y;
            y->suivant = NULL;
        } else {
            *y = *y->suivant;
        }
    }
    empiler(pile, GroupeDeCmd,x);
}